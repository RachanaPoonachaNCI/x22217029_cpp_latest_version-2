from django.contrib import admin
from .models import airConditioner, consumer

# Register your models here.
admin.site.register(airConditioner)
admin.site.register(consumer)
