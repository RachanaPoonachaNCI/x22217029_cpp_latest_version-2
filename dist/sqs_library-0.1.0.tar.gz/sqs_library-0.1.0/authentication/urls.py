from django.urls import path, re_path
from . import views

urlpatterns = [
    path("login/", views.login_api),
    path("signup/", views.signup_api),
    path("add_ac/", views.get_ac),
    path("logout/", views.login_api),
]
